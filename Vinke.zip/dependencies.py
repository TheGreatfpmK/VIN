import subprocess

# install tkinter (should be included with Python by default)

# install PIL
subprocess.run(["pip", "install", "Pillow"])

# install tkinter messagebox (should be included with tkinter by default)
