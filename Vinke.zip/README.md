# Vinke - tool for generating computer rollages

Developed and tested on Win10 with Python3.9

### Install guide:
1. download or Clone the repository
2. run dependencies.py
3. run vinke.py
4. create and have fun :)

### Examples
Folder `saves` contains some of the results of the tool on the images from `examples` folder
